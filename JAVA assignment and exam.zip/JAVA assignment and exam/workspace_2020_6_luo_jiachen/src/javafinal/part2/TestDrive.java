package javafinal.part2;

public class TestDrive {
    public static void main(String args[]){
        FinalStreamAPIQuestion.demo();
    }
}


/*Output:


	test.part2.FinalStreamAPIQuestion.demo() starting ...

	test.part2.FinalStreamAPIQuestion$Graph.demo()...
	1. show numbers (initial values) graphically on console (stdout):
	[3]	###
	[5]	#####
	[1]	#
	[4]	####
	[2]	##
	2a. Sort and Show numbers graphically ASCENDING on console (stdout):
	[1]	#
	[2]	##
	[3]	###
	[4]	####
	[5]	#####
	2b. Sort and Show numbers graphically DESCENDING on console (stdout):
	[5]	#####
	[4]	####
	[3]	###
	[2]	##
	[1]	#
	3a. multiple each number by factor (n*factor), Sort and Show numbers graphically ASCENDING on console (stdout):
	[5]	#####
	[10]	##########
	[15]	###############
	[20]	####################
	[25]	#########################
	3b. multiple each number by factor (n*factor), Sort and Show numbers graphically DESCENDING on console (stdout):
	[25]	#########################
	[20]	####################
	[15]	###############
	[10]	##########
	[5]	#####
	4a. multiple each number by factor (n*factor) THEN add offset, Sort and Show numbers graphically ASCENDING on console (stdout):
	[25]	#########################
	[30]	##############################
	[35]	###################################
	[40]	########################################
	[45]	#############################################
	4b. multiple each number by factor (n*factor) THEN add offset, Sort and Show numbers graphically DESCENDING on console (stdout):
	[45]	#############################################
	[40]	########################################
	[35]	###################################
	[30]	##############################
	[25]	#########################

	test.part2.FinalStreamAPIQuestion$Graph.demo()... done!

test.part2.FinalStreamAPIQuestion.demo() done!

Process finished with exit code 0

 */
