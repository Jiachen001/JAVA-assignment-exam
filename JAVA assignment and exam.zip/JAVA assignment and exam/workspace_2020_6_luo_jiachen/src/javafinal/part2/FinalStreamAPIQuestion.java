package javafinal.part2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class FinalStreamAPIQuestion {
    /**
     * Create a class which will show a single number,
     * as a horizontal bar graph display on console (stdout),
     * as shown in the following example:
     * <p>
     * [1] *
     * [2] **
     * [3] ***
     *
     * @author dgpeters
     */
    private class Graph {
        private String sign="#";

        private List<Integer> numbers = new ArrayList<>(Arrays.asList(3, 5, 1, 4, 2));


        /**
         * show a BAR graph on console (stdout) of the specified numerical value
         *
         * @param graphValue numerical value to display graphically
         * @return
         */
        private String barGraph(double graphValue) {
                StringBuffer output=new StringBuffer();
                long wideth=Math.round(graphValue/1);
                for (int i=0;i<wideth;i++){
                    output.append(sign);
                }
                return output.toString();
        }

        /**
         * return a BAR graph of a single numerical value as a string representation
         */
        @Override
        public String toString() {
            StringBuffer output=new StringBuffer();
            for(int line: numbers){
                output.append(barGraph(line));
                output.append(line);
                output.append("\n");
            }
            return output.toString();
        }


        /**
         * Use Lambda and Stream API to sort and display graphically on console
         * <p>
         * NOTE:
         * 1. PERFORM ALL REQUIRED OPERATIONS using Lambda and Stream API
         * 2. SHOW ALL DATA ON CONSOLE AS A BAR GRAPH USING Graph class
         */
        public void demo() {
            System.out.println("\n\t" + Graph.class.getName() + ".demo()...");

            /*
             * 1. show numbers (initial values) graphically on console (stdout):
             */
            System.out.println("\t" +"1. show numbers (initial values) graphically on console (stdout):");
            List<Integer> copy= new ArrayList<Integer>(numbers);
            copy.stream().forEach(x->System.out.println("\t["+x+"]\t"+barGraph(x)));

            /*
             * 2a. Sort and Show numbers graphically ASCENDING on console (stdout):
             */
            System.out.println("\t" +"2a. Sort and Show numbers graphically ASCENDING on console (stdout):");
            copy= new ArrayList<Integer>(numbers);
            copy.stream().sorted().forEach(x->System.out.println("\t["+x+"]\t"+barGraph(x)));
            /*
             * 2b. Sort and Show numbers graphically DESCENDING on console (stdout):
             */
            System.out.println("\t" +"2b. Sort and Show numbers graphically DESCENDING on console (stdout):");
            copy= new ArrayList<Integer>(numbers);
            Comparator<Integer> descending=(Integer x,Integer y)->y.compareTo(x);
            copy.stream().sorted(descending).forEach(x->System.out.println("\t["+x+"]\t"+barGraph(x)));


            /*
             * 3a. multiple each number by factor (n*factor), Sort and Show numbers graphically ASCENDING on console (stdout):
             */
            System.out.println("\t" +"3a. multiple each number by factor (n*factor), Sort and Show numbers graphically ASCENDING on console (stdout):");
            int factor = 5;
            copy= new ArrayList<Integer>(numbers);
            copy.stream().map(x->x*factor).sorted().forEach(x->System.out.println("\t["+x+"]\t"+barGraph(x)));
            /*
             * 3b. multiple each number by factor (n*factor), Sort and Show numbers graphically DESCENDING on console (stdout):
             */
            System.out.println("\t" +"3b. multiple each number by factor (n*factor), Sort and Show numbers graphically DESCENDING on console (stdout):");
            copy= new ArrayList<Integer>(numbers);
            copy.stream().map(x->x*factor).sorted(descending).forEach(x->System.out.println("\t["+x+"]\t"+barGraph(x)));

            /*
             * 4a. multiple each number by factor (n*factor) THEN add offset, Sort and Show numbers graphically ASCENDING on console (stdout):
             */
            System.out.println("\t" +"4a. multiple each number by factor (n*factor) THEN add offset, Sort and Show numbers graphically ASCENDING on console (stdout):");
            int offset = 20;
            copy= new ArrayList<Integer>(numbers);
            copy.stream().map(x->x*factor+offset).sorted().forEach(x->System.out.println("\t["+x+"]\t"+barGraph(x)));

            /*
             * 4b. multiple each number by factor (n*factor) THEN add offset, Sort and Show numbers graphically DESCENDING on console (stdout):
             */
            System.out.println("\t" +"4b. multiple each number by factor (n*factor) THEN add offset, Sort and Show numbers graphically DESCENDING on console (stdout):");
            copy= new ArrayList<Integer>(numbers);
            copy.stream().map(x->x*factor+offset).sorted(descending).forEach(x->System.out.println("\t["+x+"]\t"+barGraph(x)));

            System.out.println("\n\t" + Graph.class.getName() + ".demo()... done!");
        }
    } // end of inner class Graph


    /**
     * Complete the implementation of FinalStreamAPIQuestion.demo()
     * NOTE: TBD sections of code to complete
     */
    public static void demo() {
        System.out.println("\n\t" + FinalStreamAPIQuestion.class.getName() + ".demo() starting ...");

        FinalStreamAPIQuestion obj = new FinalStreamAPIQuestion();


        Graph g = obj.new Graph();
        g.demo();

        System.out.println("\n" + FinalStreamAPIQuestion.class.getName() + ".demo() done!");
    }

} // end class FinalStreamAPIQuestion

/*Output:

	test.part2.FinalStreamAPIQuestion.demo() starting ...

	test.part2.FinalStreamAPIQuestion$Graph.demo()...
	1. show numbers (initial values) graphically on console (stdout):
	[3]	###
	[5]	#####
	[1]	#
	[4]	####
	[2]	##
	2a. Sort and Show numbers graphically ASCENDING on console (stdout):
	[1]	#
	[2]	##
	[3]	###
	[4]	####
	[5]	#####
	2b. Sort and Show numbers graphically DESCENDING on console (stdout):
	[5]	#####
	[4]	####
	[3]	###
	[2]	##
	[1]	#
	3a. multiple each number by factor (n*factor), Sort and Show numbers graphically ASCENDING on console (stdout):
	[5]	#####
	[10]	##########
	[15]	###############
	[20]	####################
	[25]	#########################
	3b. multiple each number by factor (n*factor), Sort and Show numbers graphically DESCENDING on console (stdout):
	[25]	#########################
	[20]	####################
	[15]	###############
	[10]	##########
	[5]	#####
	4a. multiple each number by factor (n*factor) THEN add offset, Sort and Show numbers graphically ASCENDING on console (stdout):
	[25]	#########################
	[30]	##############################
	[35]	###################################
	[40]	########################################
	[45]	#############################################
	4b. multiple each number by factor (n*factor) THEN add offset, Sort and Show numbers graphically DESCENDING on console (stdout):
	[45]	#############################################
	[40]	########################################
	[35]	###################################
	[30]	##############################
	[25]	#########################

	test.part2.FinalStreamAPIQuestion$Graph.demo()... done!

test.part2.FinalStreamAPIQuestion.demo() done!

Process finished with exit code 0


 */