package javafinal.part1;

public class TestDriver {
    public static void main(String[] args){
        Object lock=new Object();
        AlterNativeThread lowerCase=new AlterNativeThread("abcdefghijklmnopqrstuvwxyz",lock,true);
        AlterNativeThread upperCase=new AlterNativeThread("ABCDEFGHIJKLMNOPQRSTUVWXYZ",lock,false);
        lowerCase.start();
        upperCase.start();
        try {
            lowerCase.join();
            upperCase.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}

/*out put:

aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ
Process finished with exit code 0

 */
