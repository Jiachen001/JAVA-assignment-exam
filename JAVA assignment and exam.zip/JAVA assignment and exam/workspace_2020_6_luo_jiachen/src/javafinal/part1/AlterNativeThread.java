package javafinal.part1;

public class AlterNativeThread extends Thread {
    private static boolean switchOn=true;
    private boolean runCondition;
    private Object lock;
    private String data;

    public AlterNativeThread(String data,Object lock,boolean runCondition){
        this.data=data;
        this.lock=lock;
        this.runCondition=runCondition;
    }

    @Override
    public void run(){
        int index=0;
        while (true){
            synchronized (lock){
                if(switchOn==runCondition){
                    System.out.print(data.charAt(index));
                    index++;
                    switchOn=!runCondition;
                }
            }
            if(index==data.length()){
                break;
            }
        }
    }
}
/*out put:

aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ
Process finished with exit code 0

 */
