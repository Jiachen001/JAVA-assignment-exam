package Homework;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Student extends Parent {
	private double GPA;
	public  static void demo() {
		List<Student> students = new ArrayList<Student>();
		try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\22978\\eclipse-workspace\\Hello\\src\\Homework\\student.csv"))) {
		    String line;
		    int lineNum=0;
		    while ((line = br.readLine()) != null) {
		    	if(lineNum!=0) {
			        String[] studentStr = line.split(",");	
			        Student student= new Student();
			        student.setID(Integer.parseInt(studentStr[0]));			     
			        student.setAge(Integer.parseInt(studentStr[1]));
			        student.setFirstName(studentStr[2]);
			        student.setLastName(studentStr[3]);
			        student.setGPA(Double.parseDouble(studentStr[4]));
			        students.add(student);
		    	}
		    	lineNum++;
		    }
		    System.out.println("---------SortbyLastName---------");
		    Collections.sort(students, new SortbyLastName() );		  
		    displayStudents(students);
		    System.out.println("---------SortbyFirstName---------");
		    Collections.sort(students, new SortbyFirstName() );		  
		    displayStudents(students);
		    System.out.println("---------SortbyAge---------");
		    Collections.sort(students, new SortbyAge() );		  
		    displayStudents(students);
		    System.out.println("---------SortbyGPA---------");
		    Collections.sort(students, new SortbyGPA() );		  
		    displayStudents(students);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public double getGPA() {
		return GPA;
	}
	public void setGPA(double gPA) {
		GPA = gPA;
	}
	
	public static void displayStudents(List<Student> students) {
		for (Student s: students) {
			System.out.println("ID: "+s.getID()+", Age:"+s.getAge()+", First Name:"+s.getFirstName()+
			", Last Name:"+s.getLastName()+", GPA:"+s.getGPA());
		}
	}
	

}


class SortbyLastName implements Comparator<Student> 
{ 
    // Used for sorting in ascending order of 
    // roll number 
    public int compare(Student a, Student b) 
    { 
        return a.getLastName().compareTo(b.getLastName()); 
    } 
} 
  
class SortbyFirstName implements Comparator<Student> 
{ 
    // Used for sorting in ascending order of 
    // roll name 
    public int compare(Student a, Student b) 
    { 
        return a.getFirstName().compareTo(b.getFirstName()); 
    } 
}
class SortbyAge implements Comparator<Student> 
{ 
    // Used for sorting in ascending order of 
    // roll number 
    public int compare(Student a, Student b) 
    { 
        return a.getAge() - b.getAge(); 
    } 
} 
  
class SortbyGPA implements Comparator<Student> 
{ 
    // Used for sorting in ascending order of 
    // roll name 
    public int compare(Student a, Student b) 
    { 
    	double sub=a.getGPA()-b.getGPA();
    	if (sub>0) {
    		return 1;
    	}else if(sub <0) {
    		return -1;
    	}else {
    		return 0;
    	}
    } 
}
