package Homework;

public class Driver {
	public static void main(String[] args) {

		Student.demo();
	}

}
