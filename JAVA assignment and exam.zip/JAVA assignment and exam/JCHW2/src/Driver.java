public class Driver {
    public static void main(String args[]){
        School school=new School();
        school.demo();
    }
}
