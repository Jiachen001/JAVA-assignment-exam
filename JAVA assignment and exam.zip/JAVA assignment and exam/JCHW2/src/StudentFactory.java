public class StudentFactory extends AbstractFactory {
    @Override
    public Person getObject() {
        return new Student();
    }
}
