public class Student extends Person implements Comparable<Student>{
    private int StudentID;
    private double GPA;

    public Student(){

    }
    public Student(int studentID,int ID, int age, String firstName, String lastName,double GPA) {
        super(ID, age, firstName, lastName);
        this.StudentID=studentID;
        this.GPA=GPA;
    }

    public void readFromString(String CSV){
        String[] data=CSV.split(",");
        this.setID(Integer.parseInt(data[0]));
        this.setStudentID(Integer.parseInt(data[1]));
        this.setAge(Integer.parseInt(data[2]));
        this.setFirstName(data[3]);
        this.setLastName(data[4]);
        this.setGPA(Double.parseDouble(data[5]));
    }

    public int getStudentID() {
        return StudentID;
    }

    public void setStudentID(int studentID) {
        StudentID = studentID;
    }

    public double getGPA() {
        return GPA;
    }

    public void setGPA(double GPA) {
        this.GPA = GPA;
    }

    @Override
    public int compareTo(Student student) {
        double sub=this.getGPA()-student.getGPA();
        if (sub>0) {
            return 1;
        }else if(sub <0) {
            return -1;
        }else {
            return 0;
        }
    }
}
