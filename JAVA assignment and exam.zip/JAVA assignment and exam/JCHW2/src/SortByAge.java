import java.util.Comparator;

public class SortByAge implements Comparator<Student>
{
    // Used for sorting in ascending order of
    // roll number
    public int compare(Student a, Student b)
    {
        return a.getAge() - b.getAge();
    }
}