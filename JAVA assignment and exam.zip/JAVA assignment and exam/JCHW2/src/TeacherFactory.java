public class TeacherFactory extends  AbstractFactory {
    @Override
    public Person getObject() {
        return new Teacher();
    }
}
