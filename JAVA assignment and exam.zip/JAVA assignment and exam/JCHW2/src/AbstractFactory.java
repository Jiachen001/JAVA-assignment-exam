public abstract class AbstractFactory {
    public abstract Person getObject();
}
