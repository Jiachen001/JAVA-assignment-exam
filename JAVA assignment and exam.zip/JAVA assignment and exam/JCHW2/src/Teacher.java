public class Teacher extends Person {
    private double wage;

    public Teacher(int ID, int age, String firstName, String lastName, double wage) {
        super(ID, age, firstName, lastName);
        this.wage = wage;
    }

    public Teacher() {
    }

    public void readFromString(String CSV){
        String[] data=CSV.split(",");
        this.setID(Integer.parseInt(data[0]));
        this.setAge(Integer.parseInt(data[1]));
        this.setFirstName(data[2]);
        this.setLastName(data[3]);
        this.setWage(Double.parseDouble(data[4]));
    }

    public double getWage() {
        return wage;
    }

    public void setWage(double wage) {
        this.wage = wage;
    }
}
