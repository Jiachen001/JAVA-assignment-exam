import java.util.Comparator;

public class SortByLastName implements Comparator<Student>
{
    // Used for sorting in ascending order of
    // roll number
    public int compare(Student a, Student b)
    {
        return a.getLastName().compareTo(b.getLastName());
    }
}
