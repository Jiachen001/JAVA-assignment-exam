import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class School {
    private List<Student> enrolledStudents=new ArrayList<Student>();
    private List<Teacher> enrolledTeachers=new ArrayList<Teacher>();

    public void enrollStudent(Student student){
        enrolledStudents.add(student);
    }

    public void enrollTeacher(Teacher teacher){
        enrolledTeachers.add(teacher);
    }

    public List<Student> sort(int method){
        List<Student> outputStudents= new ArrayList<Student>(enrolledStudents);
        switch (method){
            case 0:
                Collections.sort(outputStudents);
                break;
            case 1:
                Collections.sort(outputStudents,new SortByAge());
                break;
            case 2:
                Collections.sort(outputStudents,new SortByLastName());
                break;

        }
        return outputStudents;
    }


    public void displayStudents(List<Student> students){
        for (Student s: students) {
            System.out.println("Student {ID: "+s.getID()+"Student ID: "+s.getStudentID()+", Age:"+s.getAge()+", First Name:"+s.getFirstName()+
                    ", Last Name:"+s.getLastName()+", GPA:"+s.getGPA()+"}");
        }
    }


    public void displayTeachers(List<Teacher> teachers){
        for (Teacher t: teachers) {
            System.out.println("Teacher {ID: "+t.getID()+", Age:"+t.getAge()+", First Name:"+t.getFirstName()+
                    ", Last Name:"+t.getLastName()+", Wage:"+t.getWage()+"}");
        }
    }

    public void demo(){
        AbstractFactory teacherFactory=new TeacherFactory();
        AbstractFactory studentFactory=new StudentFactory();

        try (BufferedReader sbr = new BufferedReader(new FileReader("student.csv"));
        BufferedReader tbr = new BufferedReader(new FileReader("teacher.csv"));) {
            String line;
            int lineNum=0;
            while ((line = sbr.readLine()) != null) {
                if(lineNum!=0) {
                    Student student= (Student) studentFactory.getObject();
                    student.readFromString(line);
                    enrolledStudents.add(student);
                }
                lineNum++;
            }

            lineNum=0;
            while ((line = tbr.readLine()) != null) {
                if(lineNum!=0) {
                    Teacher teacher= (Teacher) teacherFactory.getObject();
                    teacher.readFromString(line);
                    enrolledTeachers.add(teacher);
                }
                lineNum++;
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<Student> sortByGPA=sort(0);
        List<Student> sortByAge=sort(1);
        List<Student> sortByLastName=sort(2);
        System.out.println("----------sortByGPA------------");
        displayStudents(sortByGPA);
        displayTeachers(enrolledTeachers);
        System.out.println("----------sortByAge------------");
        displayStudents(sortByAge);
        displayTeachers(enrolledTeachers);
        System.out.println("----------sortByLastName------------");
        displayStudents(sortByLastName);
        displayTeachers(enrolledTeachers);


    }
}
