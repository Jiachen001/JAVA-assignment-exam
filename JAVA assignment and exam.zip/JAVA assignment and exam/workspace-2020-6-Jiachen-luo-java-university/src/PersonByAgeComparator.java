import java.util.Comparator;

public class PersonByAgeComparator implements Comparator<AbstractPersonAPI> {
    @Override
    public int compare(AbstractPersonAPI t1, AbstractPersonAPI t2) {
        return t1.getAge()-t2.getAge();
    }
}
