public class NortheasternU extends UniversityBase {

    public void demo(){
        Student s1=new Student(1,"Declan","Tea",25,4.0,1);
        Student s2=new Student(2,"Xuanhe","Wang",20,4.0,2);
        Student s3=new Student(3,"Jiachen","Luo",20,4.0,3);
        addStudent(s1);
        addStudent(s2);
        addStudent(s3);
        Employee e1=new Employee(1000,"John","Tao",30,1000);
        Employee e2=new Employee(1001,"Aliec","God",32,1002);
        Employee e3=new Employee(1002,"Great","Rain",33,1003);
        addEmployee(e1);
        addEmployee(e2);
        addEmployee(e3);

        System.out.println("------Without sort-------");
        show();

        System.out.println("------Sort By ID-------");
        sortByID(getStudents());
        sortByID(getEmployees());
        show();


        System.out.println("------Sort By FirstName-------");
        sortByFirstName(getStudents());
        sortByFirstName(getEmployees());
        show();


        System.out.println("------Sort By LastName-------");
        sortByLastName(getStudents());
        sortByLastName(getEmployees());
        show();

        System.out.println("------Sort By Age-------");
        sortByAge(getStudents());
        sortByAge(getEmployees());
        show();
    }


}
