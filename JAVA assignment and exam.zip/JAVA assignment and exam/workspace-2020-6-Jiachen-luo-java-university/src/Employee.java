public class Employee extends Person {
    private int wage;

    public Employee() {
    }

    public Employee(int id, String firstName, String lastName, int age, int wage) {
        super(id, firstName, lastName, age);
        this.wage = wage;
    }

    public int getWage() {
        return wage;
    }

    public void setWage(int wage) {
        this.wage = wage;
    }

    @Override
    public String toString() {
        return "Employee{ID=" +getId()+", First Name="+getFirstName()+", Last Name="+getLastName()+", age="+getAge()+
                ", wage=" + wage +
                '}';
    }
}
