import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UniversityBase extends AbstractSchoolAPI {
    List<AbstractPersonAPI> students;
    List<AbstractPersonAPI> employees;

    public UniversityBase() {
        students=new ArrayList<AbstractPersonAPI>();
        employees=new ArrayList<AbstractPersonAPI>();
    }

    @Override
    public void addEmployee(AbstractPersonAPI employee) {
        employees.add(employee);

    }

    @Override
    public void addStudent(AbstractPersonAPI student) {
        students.add(student);
    }

    @Override
    public String getEmployeesInfo() {
        int size=employees.size();
        return "There are "+size+" employees.";
    }

    @Override
    public void showEmployees() {
        System.out.println("Employees:");
        for(AbstractPersonAPI e: employees){
            Employee employee=(Employee) e;
            System.out.println(employee.toString());
        }
    }

    @Override
    public String getStudentsInfo() {
        int size=students.size();
        return "There are "+size+" enrolled students.";
    }

    @Override
    public void showStudents() {
        System.out.println("Students:");
        for(AbstractPersonAPI s: students){
            Student student=(Student) s;
            System.out.println(student.toString());
        }
    }

    @Override
    public void show() {
        showStudents();
        showEmployees();
    }

    public List<AbstractPersonAPI> getStudents() {
        return students;
    }


    public List<AbstractPersonAPI> getEmployees() {
        return employees;
    }

    public List<AbstractPersonAPI> sortByID(List<AbstractPersonAPI> list){
//        List<AbstractPersonAPI> sortList = new ArrayList<AbstractPersonAPI>(list);
        Collections.sort(list,new PersonByIDComparator());
        return list;
    }

    public List<AbstractPersonAPI> sortByFirstName(List<AbstractPersonAPI> list){
//        List<AbstractPersonAPI> sortList = new ArrayList<AbstractPersonAPI>(list);
        Collections.sort(list,new PersonByFirstNameComparator());
        return list;
    }

    public List<AbstractPersonAPI> sortByLastName(List<AbstractPersonAPI> list){
//        List<AbstractPersonAPI> sortList = new ArrayList<AbstractPersonAPI>(list);
        Collections.sort(list,new PersonByLastNameComparator());
        return list;
    }

    public List<AbstractPersonAPI> sortByAge(List<AbstractPersonAPI> list){
//        List<AbstractPersonAPI> sortList = new ArrayList<AbstractPersonAPI>(list);
        Collections.sort(list,new PersonByAgeComparator());
        return list;
    }

}
