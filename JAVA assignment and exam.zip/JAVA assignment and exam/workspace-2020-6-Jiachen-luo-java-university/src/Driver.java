public class Driver {
    public static void main(String args[]){
        NortheasternU northeasternU=new NortheasternU();
        northeasternU.demo();
    }
    /**
     * Output:

     ------Without sort-------
     Students:
     Student{ID=1, First Name=Declan, Last Name=Tea, age=25, GPA=4.0, studentID=1}
     Student{ID=2, First Name=Xuanhe, Last Name=Wang, age=20, GPA=4.0, studentID=2}
     Student{ID=3, First Name=Jiachen, Last Name=Luo, age=20, GPA=4.0, studentID=3}
     Employees:
     Employee{ID=1000, First Name=John, Last Name=Tao, age=30, wage=1000}
     Employee{ID=1001, First Name=Aliec, Last Name=God, age=32, wage=1002}
     Employee{ID=1002, First Name=Great, Last Name=Rain, age=33, wage=1003}
     ------Sort By ID-------
     Students:
     Student{ID=1, First Name=Declan, Last Name=Tea, age=25, GPA=4.0, studentID=1}
     Student{ID=2, First Name=Xuanhe, Last Name=Wang, age=20, GPA=4.0, studentID=2}
     Student{ID=3, First Name=Jiachen, Last Name=Luo, age=20, GPA=4.0, studentID=3}
     Employees:
     Employee{ID=1000, First Name=John, Last Name=Tao, age=30, wage=1000}
     Employee{ID=1001, First Name=Aliec, Last Name=God, age=32, wage=1002}
     Employee{ID=1002, First Name=Great, Last Name=Rain, age=33, wage=1003}
     ------Sort By FirstName-------
     Students:
     Student{ID=1, First Name=Declan, Last Name=Tea, age=25, GPA=4.0, studentID=1}
     Student{ID=3, First Name=Jiachen, Last Name=Luo, age=20, GPA=4.0, studentID=3}
     Student{ID=2, First Name=Xuanhe, Last Name=Wang, age=20, GPA=4.0, studentID=2}
     Employees:
     Employee{ID=1001, First Name=Aliec, Last Name=God, age=32, wage=1002}
     Employee{ID=1002, First Name=Great, Last Name=Rain, age=33, wage=1003}
     Employee{ID=1000, First Name=John, Last Name=Tao, age=30, wage=1000}
     ------Sort By LastName-------
     Students:
     Student{ID=3, First Name=Jiachen, Last Name=Luo, age=20, GPA=4.0, studentID=3}
     Student{ID=1, First Name=Declan, Last Name=Tea, age=25, GPA=4.0, studentID=1}
     Student{ID=2, First Name=Xuanhe, Last Name=Wang, age=20, GPA=4.0, studentID=2}
     Employees:
     Employee{ID=1001, First Name=Aliec, Last Name=God, age=32, wage=1002}
     Employee{ID=1002, First Name=Great, Last Name=Rain, age=33, wage=1003}
     Employee{ID=1000, First Name=John, Last Name=Tao, age=30, wage=1000}
     ------Sort By Age-------
     Students:
     Student{ID=3, First Name=Jiachen, Last Name=Luo, age=20, GPA=4.0, studentID=3}
     Student{ID=2, First Name=Xuanhe, Last Name=Wang, age=20, GPA=4.0, studentID=2}
     Student{ID=1, First Name=Declan, Last Name=Tea, age=25, GPA=4.0, studentID=1}
     Employees:
     Employee{ID=1000, First Name=John, Last Name=Tao, age=30, wage=1000}
     Employee{ID=1001, First Name=Aliec, Last Name=God, age=32, wage=1002}
     Employee{ID=1002, First Name=Great, Last Name=Rain, age=33, wage=1003}

     Process finished with exit code 0

    **/

}
