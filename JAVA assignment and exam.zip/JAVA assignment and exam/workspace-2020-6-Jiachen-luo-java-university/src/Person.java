public class Person extends AbstractPersonAPI {
    private int Id;
    private String firstName;
    private String lastName;
    private int age;

    public Person() {
    }

    public Person(int id, String firstName, String lastName, int age) {
        Id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }

    @Override
    public int getId() {
        return Id;
    }

    @Override
    public void setId(int id) {
        this.Id=id;
    }

    @Override
    public String getFirstName() {
        return firstName;
    }

    @Override
    public void setFirstName(String firstName) {
        this.firstName=firstName;
    }

    @Override
    public String getLastName() {
        return lastName;
    }

    @Override
    public void setLastName(String lastName) {
        this.lastName=lastName;
    }

    @Override
    public int getAge() {
        return age;
    }

    @Override
    public void setAge(int age) {
        this.age=age;
    }

    @Override
    public void show() {
        System.out.println("ID: "+Id+", First Name:"+firstName+", Last Name:"+lastName+", Age:"+age);
    }
}
