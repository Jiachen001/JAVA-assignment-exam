public abstract class AbstractSchoolAPI {

    public abstract void addEmployee(AbstractPersonAPI employee);

    public abstract void addStudent(AbstractPersonAPI student);

    public abstract String getEmployeesInfo();

    public abstract void showEmployees();

    public abstract String getStudentsInfo();

    public abstract void showStudents();

    public abstract void show();

}
