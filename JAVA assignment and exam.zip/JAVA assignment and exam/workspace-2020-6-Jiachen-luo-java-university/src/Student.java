public class Student extends Person {
    private double GPA;
    private int studentID;

    public Student() {
    }

    public Student(int id, String firstName, String lastName, int age, double GPA, int studentID) {
        super(id, firstName, lastName, age);
        this.GPA = GPA;
        this.studentID = studentID;
    }

    public double getGPA() {
        return GPA;
    }

    public void setGPA(double GPA) {
        this.GPA = GPA;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    @Override
    public String toString() {
        return "Student{ID=" +getId()+", First Name="+getFirstName()+", Last Name="+getLastName()+", age="+getAge()+
                ", GPA=" + GPA +
                ", studentID=" + studentID +
                '}';
    }
}
