import java.util.Comparator;

public class PersonByFirstNameComparator implements Comparator<AbstractPersonAPI> {
    @Override
    public int compare(AbstractPersonAPI t1, AbstractPersonAPI t2) {
        return t1.getFirstName().compareTo(t2.getFirstName());
    }
}
