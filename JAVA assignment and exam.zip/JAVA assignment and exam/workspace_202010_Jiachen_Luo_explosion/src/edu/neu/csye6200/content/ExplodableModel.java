package edu.neu.csye6200.content;

import edu.neu.csye6200.base.AbstractExplosionModel;

public class ExplodableModel extends AbstractExplosionModel {

    public static void demo() {
        ExplosionModel explosionModel = new ExplosionModel();
        Explosion explosion = new Explosion();
        explosion.explode();

    }



    @Override
    public void add(ExplosionModel e) {

    }

    @Override
    public void explode() {

    }
}
