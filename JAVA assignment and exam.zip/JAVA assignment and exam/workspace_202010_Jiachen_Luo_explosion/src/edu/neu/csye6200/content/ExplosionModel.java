package edu.neu.csye6200.content;

import edu.neu.csye6200.base.AbstractExplosionModel;

public class ExplosionModel extends AbstractExplosionModel {

    public static void demo() {
        ExplosionModel explosionModel = new ExplosionModel();
        Explosion explosion = new Explosion();
        explosion.explode();

    }

    @Override
    public void add(ExplosionModel e) {
        System.out.println("i am ExplosionModel.add() !");
    }

    @Override
    public void explode() {
        System.out.println("i am ExplosionModel.explode() !");
    }


}
