package edu.neu.csye6200.content;

import edu.neu.csye6200.base.AbstractExplosionModel;

public class ExplosionModelD extends AbstractExplosionModel {

    public static void demo() {
        ExplosionModelD explosionModel = new ExplosionModelD();
        Explosion explosion = new Explosion();
        explosion.explode();

    }

    @Override
    public void add(ExplosionModel e) {

    }

    @Override
    public void explode() {
        System.out.println("i am ExplosionModel.explode() !");
    }


}
