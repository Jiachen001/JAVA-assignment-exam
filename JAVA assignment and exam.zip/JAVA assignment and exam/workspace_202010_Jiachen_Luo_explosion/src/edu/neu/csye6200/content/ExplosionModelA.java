package edu.neu.csye6200.content;

import edu.neu.csye6200.base.AbstractExplosionModelA;

public class ExplosionModelA extends AbstractExplosionModelA {

    public static void demo() {
        ExplosionModel explosionModel = new ExplosionModel();
        explosionModel.explode();

    }

    @Override
    public void explode() {
        System.out.println("i am ExplosionModelA.explode()!");
    }
}
