package edu.neu.csye6200.content;

public class Explosion {
    public void explode() {
        System.out.println("i am Explosion.explode()");
    }



}
