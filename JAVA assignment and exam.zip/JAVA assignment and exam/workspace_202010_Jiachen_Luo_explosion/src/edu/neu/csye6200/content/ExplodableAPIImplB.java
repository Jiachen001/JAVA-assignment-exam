package edu.neu.csye6200.content;

public class ExplodableAPIImplB implements ExplodableAPI {
    @Override
    public void explode() {
        ExplodableModel explodableModel = new ExplodableModel();
        explodableModel.explode();
    }
}
