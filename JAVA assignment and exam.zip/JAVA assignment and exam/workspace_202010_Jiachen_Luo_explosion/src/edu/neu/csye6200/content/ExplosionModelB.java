package edu.neu.csye6200.content;

import edu.neu.csye6200.base.AbstractExplosionModel;

public class ExplosionModelB extends AbstractExplosionModel {

    public static void demo() {
        ExplosionModelB explosionModel = new ExplosionModelB();
        Explosion explosion = new Explosion();
        explosion.explode();

    }

    @Override
    public void add(ExplosionModel e) {

    }

    @Override
    public void explode() {
        System.out.println("i am ExplosionModel.explode() !");
    }


}
