package edu.neu.csye6200.content;

public class ExplosionC extends Explosion {
    @Override
    public void explode() {
        ExplosionModel explosionModel = new ExplosionModel();
        explosionModel.add(explosionModel);
        System.out.println("ExplosionB");
    }
}
