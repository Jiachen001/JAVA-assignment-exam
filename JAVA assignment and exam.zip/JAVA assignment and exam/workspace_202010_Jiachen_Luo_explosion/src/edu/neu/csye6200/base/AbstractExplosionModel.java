package edu.neu.csye6200.base;

import edu.neu.csye6200.content.ExplosionModel;

/**
 * API for an Explosion Model which loads and explodes Explosion objects.
 *
 * @author dpeters
 */
public abstract class AbstractExplosionModel {
    public static final double VERSION = 1.0;

    /**
     * Add one Explosion object to model
     *
     * @param e Explosion object
     */
    public abstract void add(ExplosionModel e);

    /**
     * Explode all
     */
    public abstract void explode();



}
