package edu.neu.csye6200;

import edu.neu.csye6200.base.AbstractExplosionModel;
import edu.neu.csye6200.content.*;

public class Driver {

    public static void main(String[] args) {
        System.out.println("Project " + Driver.class.getName() + ".main()...");

        ExplosionModel.demo();

        ExplosionModelA.demo();

        ExplodableModel.demo();


        Explosion Ea = new ExplosionA();
        Ea.explode();
        Explosion Eb = new ExplosionA();
        Eb.explode();
        Explosion Ec = new ExplosionA();
        Ec.explode();

        AbstractExplosionModel AEMb = new ExplosionModelB();
        AEMb.explode();
        AbstractExplosionModel AEMc = new ExplosionModelB();
        AEMc.explode();
        AbstractExplosionModel AEMd = new ExplosionModelB();
        AEMd.explode();

        ExplodableAPI EAAa = new ExplodableAPIImplA();
        EAAa.explode();
        ExplodableAPI EAAb = new ExplodableAPIImplA();
        EAAb.explode();
        ExplodableAPI EAAc = new ExplodableAPIImplA();
        EAAc.explode();
        System.out.println("Project " + Driver.class.getName() + ".main()... done!");
    }
    /**
     * CONSOLE OUTPUT (stdout):
     Project edu.neu.csye6200.Driver.main()...

     i am Explosion.explode()
     i am ExplosionModel.explode() !
     i am Explosion.explode()
     i am ExplosionModel.add() !
     ExplosionA
     i am ExplosionModel.add() !
     ExplosionA
     i am ExplosionModel.add() !
     ExplosionA
     i am ExplosionModel.explode() !
     i am ExplosionModel.explode() !
     i am ExplosionModel.explode() !

     Project edu.neu.csye6200.Driver.main()... done!

     */

}
